function [ outputScatter ] = FOCUS_srDAS(multiline_matrix, receive_center_array, output_pos, z_focus, fs, c, mag_matrix )

%% implement receive beamforming using apodization
[image_depth , N_channel] = size(multiline_matrix);
temp_matrix = zeros(image_depth,N_channel);


%% each receive line correspond to one receive position


%% first shift each output to the coresponsding position
dx = abs(receive_center_array - output_pos);
delay_length = (sqrt(dx.^2 + z_focus^2)-z_focus);
delay_sample = round(delay_length/c*fs);

for i_receive = 1:N_channel
    current_delay = delay_sample(i_receive);
    temp_matrix(1:(end-current_delay),i_receive) = multiline_matrix((1+current_delay:end),i_receive);
end

%% finally, calculate the final focused line based on both time delay calculation and the magnitude calculation
    outputScatter = sum(temp_matrix.*mag_matrix,2);    

return; 

