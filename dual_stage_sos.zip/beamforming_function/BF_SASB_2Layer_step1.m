%% Physical properties of the transducer elements
fs = 120e6;                   %  Sampling frequency [Hz]
s_d = layer_separation;

image_depth = size(first_stage_buffer, 1);
N_channel = size(first_stage_buffer, 2);
image_depth_index = (1:image_depth)/2*c1/fs;

%% First find the position of the layer separation
[~, seperation_index] = min(abs(image_depth_index-s_d));

%% Then rescale the first portion of the image 
first_stage_buffer_1 = first_stage_buffer(1:seperation_index,:);
image_depth_new_1 = round(s_d*2/c*fs);
first_stage_buffer_new_1 = zeros(image_depth_new_1, N_channel);
% resample the first portion channel by channel
for i_chanel = 1:128
     first_stage_buffer_new_1(:,i_chanel) = resample(first_stage_buffer_1(:,i_chanel),image_depth_new_1,seperation_index);
end
%% Then shift the second portion of the image 
first_stage_buffer_2 = first_stage_buffer(seperation_index+1:end,:);
image_depth_2 = image_depth-seperation_index;
image_depth_2_new = round(image_depth_2*c2/c);
first_stage_buffer_new_2 = zeros(image_depth_2_new, N_channel);
for i_chanel = 1:128
     first_stage_buffer_new_2(:,i_chanel) = resample(first_stage_buffer_2(:,i_chanel),image_depth_2_new,image_depth_2);
end
first_stage_buffer_new = [first_stage_buffer_new_1;first_stage_buffer_new_2] ;