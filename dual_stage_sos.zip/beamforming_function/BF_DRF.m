%% Physical properties of the transducer elements
f0 = 7e6;                     %  Transducer center frequency [Hz]
fs = 120e6;                   %  Sampling frequency [Hz]
kerf = 0.035/1000;
width = pitch - kerf;           %  Width of element
element_height = 4.5/1000;    %  Height of element [m]
focus = [0 0 25]/1000;        %  Fixed focal point [m]
fi = 5e6;
num_cycle_excite = 1;
num_cycle_impulse = 1;
N_elements = 128;

%% ==== F-NUMBER-TRANSMIT
receive_hann = 1;
transmit_hann = 1;
transmit_apo_hann = 1;

impulse_response=sin(2*pi*f0*(0:1/fs:num_cycle_impulse/f0));
impulse_response=impulse_response.*hanning(max(size(impulse_response)))';
excitation=sin(2*pi*fi*(0:1/fs:num_cycle_excite/fi));
excitation=excitation.*hanning(max(size(excitation)))';

m_filter = conv(conv(excitation,impulse_response), impulse_response);
m_filter = flipdim(m_filter,2);

%% Phantom properties
image_depth = size(RF_data,2);
image_depth_index = (1:image_depth)/2*c/fs*1000;

%% Parameters of transducer array
N_image = N_elements;                   % Form one line at each imaging position
N_active = 65;                          % Number of elements used to generate a focused transmission
N_receive = 63;
N_transmit = 128;     % Number of transmission events
final_Image = zeros(image_depth,N_elements);
%% Scan parameter
% position of each transmission element
aperture_center_array = help_generateCenterArray(N_elements, pitch);
if N_transmit == N_elements
    transmit_start = 1;
    transmit_end = N_elements;
else
    transmit_start = (N_active + 1)/2;
    transmit_end = N_elements - (N_active-1)/2;
end
transmit_center_index = transmit_start:transmit_end;
transmit_center_array = aperture_center_array(transmit_center_index);

receive_center_index = 1:N_image;
receive_center_array = aperture_center_array(receive_center_index);
receive_mag_matrix =  FOCUS_apodizationMatrix(N_elements, image_depth, 0, fs,c,f_number_receive,receive_hann,pitch);
width_mag_matrix = size(receive_mag_matrix,2);
mag_offset = (N_image - 1)/2;

for i_line = 1:N_transmit
    current_center_index = transmit_center_index(i_line);
    temp_beamform_matrix = squeeze(RF_data(current_center_index,:,:));
    
    mag_startPos = N_elements +1 - current_center_index;
    current_mag_matrix = receive_mag_matrix(:, (mag_startPos):(mag_startPos+2*mag_offset));
    final_Image(:,i_line) = FOCUS_DRF(temp_beamform_matrix,receive_center_array, transmit_center_array(i_line), fs, c, current_mag_matrix);
    
    fprintf('Tranmission:::\t Processing line %d.\t\t %0.05f %% \t finished.\n',i_line,i_line/N_transmit*100 );
    
end

%%
N_image = N_transmit;
image_center_array = help_generateCenterArray(N_image, pitch);
image_center_index = ((N_elements+1)/2-(N_image-1)/2):((N_elements+1)/2+(N_image-1)/2);
final_Image = final_Image(:,1:N_transmit);

%% Perform matched filtering
for i_line = 1:N_image
    temp = xcorr(final_Image(:,i_line),m_filter);
    final_Image(:,i_line) = temp(image_depth:end);
end

%% make the image
active_center_array = transmit_center_array;
IMG_make_image;
