%  Procedure for doing dynamic focusing. Compared to the generic focusing
%  by field ii, this function has the capacity to calculate multiple
%  focused scan lines in the azimuth direction
%
%
%  Calling:  [ outputScatter ] = DoDynamicFocusing(scatterField, input_pos , output_pos, fs,c )
%
%  Parameters:  scatterField - output from  calc_scat_multi. Converted to
%                               a longer version, so that time index start
%                               with 0.
%               input_pos -    center of the elements of the transducer [mm]
%               output_pos -   positions that we are interested in getting
%                              a dynamically focused line [mm]
%               fs -           sampling frequency [Hz]
%               c -            speed of light [m/s]
%  Return:      outputScatter - ouput of scatter field at the output_pos
%

function [ outputScatter ] = FOCUS_DRF(multiline_matrix, transmit_center_array,output_center_array, fs,c,mag_matrix )
[image_depth , N_channel] = size(multiline_matrix);
N_output = size(output_center_array,1);
delay_matrix = zeros(size(multiline_matrix));
z = (1:image_depth)/2*c/fs;
outputScatter = zeros(image_depth,N_output);
temp_matrix = zeros(image_depth,N_channel);
% each receive line correspond to one receive position
for i_output = 1:N_output
    output_pos = output_center_array(i_output);
    for i = 1:N_channel
        delay_matrix(:,i) = round((sqrt((transmit_center_array(i)-output_pos).^2 + z.^2)-z)/c*fs);
    end
    
    %several matrices used to compute the portion of aperture to us    
    for  j_depth = 1: image_depth
        for i_width = 1:N_channel
            if j_depth+delay_matrix(j_depth,i_width) <= image_depth
                temp_matrix(j_depth, i_width) = multiline_matrix(j_depth+delay_matrix(j_depth,i_width),i_width);
            end
        end
    end
    outputScatter(:,i_output) = sum(temp_matrix.*mag_matrix,2);  
   
end
end

