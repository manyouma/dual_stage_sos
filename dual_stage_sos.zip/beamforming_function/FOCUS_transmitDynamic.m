
function new_line = FOCUS_transmitDynamic(multiline_matrix,transmit_center_array,output_pos,input_depth, fs,c,mag_matrix)
%% make sure that the first dimension of the matrix is the depth of the
% phantom
if size(multiline_matrix,2) > size(multiline_matrix,1)
    multiline_matrix = multiline_matrix';
end
[image_depth , N_channel] = size(multiline_matrix);

% initializations
delay_matrix = zeros(size(multiline_matrix));

%% do the time delay calculation
for j_depth = 1:image_depth
    current_depth = j_depth/2*c/fs;
    if current_depth < input_depth
        delayDir = -1;
    else
        delayDir = +1;
    end
    deltaX = sqrt((transmit_center_array-output_pos).^2 + (input_depth - current_depth).^2)-abs(input_depth - current_depth);
    delay_matrix(j_depth,:) = delayDir*round(2*deltaX/c*fs);
end

%% caculate the delayed lines from different transmission
temp_matrix = zeros(image_depth, N_channel);
for j_depth = 1:image_depth
    for i_width = 1:N_channel
        if j_depth+delay_matrix(j_depth,i_width) <= image_depth && j_depth+delay_matrix(j_depth,i_width) >=1
            temp_matrix(j_depth,i_width) = multiline_matrix(j_depth+delay_matrix(j_depth,i_width),i_width);
        end
    end
end

%% calculate the final output line
new_line = sum(temp_matrix.*mag_matrix,2);
end