function mag_matrix = FOCUS_apodizationMatrix(N_channel, image_depth,source_depth, fs,c,tranmit_f_number,use_hamming_window,pitch)

max_depth = image_depth(end)-source_depth;
middle_element = N_channel;
matrix_channel = 2*N_channel - 1;  
mag_matrix = zeros(image_depth, matrix_channel);


endApoLength = min(double2odd(max_depth/(tranmit_f_number*pitch)),matrix_channel );
apo_length_index = abs(1:2:endApoLength);
num_apo_depth = max(size(apo_length_index));

num_apo_matrix = zeros(num_apo_depth, matrix_channel);
for i_depth = 1:num_apo_depth
    current_length = apo_length_index(i_depth);
    off_set = (current_length-1)/2;
    if use_hamming_window
        num_apo_matrix(i_depth,(middle_element-off_set):(middle_element+off_set)) = hanning(current_length);
    else
        num_apo_matrix(i_depth,(middle_element-off_set):(middle_element+off_set)) = ones(current_length,1);
    end
end

depth_matrix = abs((1:image_depth)/fs*c/2-source_depth);
width_index = min(double2odd(depth_matrix/(tranmit_f_number*pitch)),matrix_channel);

for i_depth = 1:image_depth 
    row_num = (width_index(i_depth)+1)/2;
    mag_matrix(i_depth,:) = num_apo_matrix(row_num,:);
end 

return

function oddNumber = double2odd(x)
    oddNumber = max(1,floor((x-1)/2)*2+1);
return;