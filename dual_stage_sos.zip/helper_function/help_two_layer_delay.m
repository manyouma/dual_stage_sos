function tof_difference = help_two_layer_delay(scatter_position, aperture_center_array, layer_separation, c1, c2,fs)
    N_element = max(size(aperture_center_array));
    tof_difference = zeros(size(aperture_center_array));
    for i_element = 1:N_element
        p1 = [aperture_center_array(i_element),0];
        p2 = scatter_position;
        ds = layer_separation;
        [s1, s2] = help_two_point_snell_law( p1, p2, ds, c1, c2 );
        tof_difference(i_element) = (s1/c1+s2/c2) - sqrt(sum((p2-p1).^2))/c1;
    end
    tof_difference = round(tof_difference*fs);
end