function [ delayVector ] = help_transmitDelayVector(focus, c, centerArray )
%[ index, delayVector ] = GenerateDelayVector( N_elements , focus, c, centerArray )

focus_x = focus(1);
focus_z = focus(3);

if focus_z > 0
    distance_offset = focus_z-sqrt((centerArray-focus_x).^2+focus_z^2);
else
    distance_offset = (sqrt((centerArray-focus_x).^2+focus_z^2)+focus_z);
end

delayVector = distance_offset/c;
delayVector = delayVector';

end

