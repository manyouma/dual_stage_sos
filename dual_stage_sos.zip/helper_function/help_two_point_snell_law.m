function [ s1, s2 ] = help_two_point_snell_law( p1, p2, ds, c1, c2 )
%TWO_POINT_SNELL_LAW This function take the spatial coodinates of two
%points: p1 and p2, the axial position of the layer separation ds, and the
% speed sound in the two layers c1 and c2 and returns the distance traveled
% in both layers. 
d1 = ds - p1(2);
d2 = p2(2) - ds;

x = abs(p2(1)-p1(1));
syms x1;
a = eval(solve((c1^2*(x-x1)^2)/((x-x1)^2+d2^2) == (c2^2*x1^2)/(x1^2+d1^2),x1));
num = find((a<x) .* (a>0));
xx1 = a(num(1));
s1 = sqrt(xx1^2+d1^2);
s2 = sqrt((x-xx1)^2+d2^2);
end