function output_pos = help_resolutionPos(inputPos, c1, c2, c0, s_d)

num_scatters = max(size(inputPos));
output_pos = zeros(size(inputPos));
for i = 1:num_scatters
    if inputPos(i) < s_d
        output_pos(i) = inputPos(i)*c0/c1;
    else
        output_pos(i) = s_d*c0/c1+(inputPos(i)-s_d)*c0/c2;
    end
end

end