%  Procedure to align the received echos from different received lines.
%  This version of the function also accomodate the case where the received
%  signal arrived before the transmission ended. In this case, the
%  prematurely arrived portion of the echo will be truncated.
%
%
%  Calling:  [ newLine ] = convert2FullLength(v,t1,fs,c,image_depth)
%
%  Parameters:  v -            output from  calc_scat_multi or calc_scat
%               t1 -           starting time reported by the same function            
%               fs -           sampling frequency [Hz]
%               c -            speed of light [m/s]
%               image_depth -  desired full length of the signal
%  Return:      newLine  -     output of the signal starting from time
%                              zero
%
%  Version 3.00  Mar 12, 2014 MMY  protect overflow
%  Version 2.00, Jul 07, 2014 MMY
%  Version 1.00, May 31, 2014 MMY


function newLine = help_convert2FullLength(v,t1,fs,c,image_depth)

N_channel = size(v,2);
newLine = zeros(image_depth,N_channel);
length = size(v,1);
t_sample = round(t1*fs);

if t_sample+length > image_depth
    v = v(1:image_depth-t_sample,:);
end

length = size(v,1);

if t1 > 0
    newLine(t_sample+1:t_sample+length,:) = v;
else
    newLine(1:t_sample+length,:) = v(1-t_sample:end,:);
end


end
