function [ outputMatrix  ] = generateHammingMatrix( aperture_width, N_x, N_y , hamming_x, hamming_y)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

if hamming_x 
    x_hamming_vector = hamming(aperture_width);
else
    x_hamming_vector = ones(aperture_width,1);
end

if hamming_y 
    y_hamming_vector = hamming(aperture_width);
else
    y_hamming_vector = ones(aperture_width,1);
end

sub_hamming_x =  zeros(N_x,1);
sub_hamming_y = zeros(1,N_y);

if N_x < aperture_width
    sub_hamming_x = x_hamming_vector((aperture_width+1)/2-(N_x-1)/2:(aperture_width+1)/2+(N_x-1)/2);
else
    sub_hamming_x((N_x+1)/2-(aperture_width-1)/2:(N_x+1)/2+(aperture_width-1)/2) = x_hamming_vector;
end

if N_y < aperture_width
    sub_hamming_y = y_hamming_vector((aperture_width+1)/2-(N_y-1)/2:(aperture_width+1)/2+(N_y-1)/2)';
else
    sub_hamming_y((N_y+1)/2-(aperture_width-1)/2:(N_y+1)/2+(aperture_width-1)/2) =y_hamming_vector';
end
%%%%%%%%%%%%%%%%
sub_hamming_x = sub_hamming_x/sqrt(sum(sub_hamming_x));
sub_hamming_y = sub_hamming_y/sqrt(sum(sub_hamming_y));
outputMatrix = repmat(sub_hamming_x,1,N_y).*repmat(sub_hamming_y,N_x,1);
end

