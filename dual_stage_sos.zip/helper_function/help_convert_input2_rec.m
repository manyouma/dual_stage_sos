function rect_coord =  convert_input2_rec(input2)

a = input2(1); 
b = input2(2);
c = input2(3)-input2(1);
d = input2(4)-input2(2);
rect_coord = [a,b,c,d];
end