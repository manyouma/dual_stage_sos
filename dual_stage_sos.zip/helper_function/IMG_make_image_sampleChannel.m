%% Start to make the pictures
[image_depth, no_lines] = size(final_Image);

dynamic_range = 60;
D = 1;   %compression along the z axis



env=zeros(round(image_depth/D),no_lines);
for i=1:no_lines
    rf_env=abs(hilbert(final_Image(:,i)));
    rf_env=rf_env(1:D:max(size(rf_env)));
    env(1:max(size(rf_env)),i)=rf_env;
end


%  Do logarithmic compression to a 60 dB dynamic range

log_env = env/max(max(env));
log_env=20*log10(log_env);
log_env=127*(log_env+dynamic_range)/dynamic_range;
log_env(log_env<0) = 0;



% 127 comes from the pixel value



ID=1;
[n,m]=size(log_env);
new_env=zeros(n,m*ID);
equivalent_Image = zeros(n,m*ID);

for i=1:n
    equivalent_Image(i,:) = interp(env(i,:),ID);
    new_env(i,:)=interp(log_env(i,:),ID);
end
[n,m]=size(new_env);

fn=fs;
%  imagesc(image_width_index*1000,image_depth_index,new_env)
image(new_env);

colormap(gray(128))

% drawnow