%  Procedure for calculating the center of elements in a certain aperture
%
%  Calling:  centerArray =  generateCenterArray(N_elements, pitch)
%
%  Parameters:  N_elements - Number of physical elements in the Array
%               pitch -      Distance between the center of elements [m]
%              
%  Return:      centerArray - positions of the centers of elements [m]
%
%  Version 1.00, Jun 10, 2014 MMY

function centerArray =  generateCenterArray(N_elements, pitch)
%% centerArray =  generateCenterArray(N_elements, pitch)

if mod(N_elements,2)==0 
    extreme = (N_elements/2-1/2)*pitch;
else
    extreme = (N_elements-1)/2*pitch;
end

centerArray = linspace(-extreme, extreme, N_elements)';
end