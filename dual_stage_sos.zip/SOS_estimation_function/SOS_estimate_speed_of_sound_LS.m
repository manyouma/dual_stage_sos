function [velocity_estimate,z_position] = SOS_estimate_speed_of_sound_LS(testbed,current_guess,start_pos,end_pos,fs,aperture_center_array,display_graph,z_focus )

depth_index = start_pos:end_pos;
time_vector = depth_index/fs;
% hilbert transform
testbedh = abs(hilbert(testbed));
if display_graph
    subplot(2,2,1);
    imagesc(testbedh);
    title('Hilbert envelope');
    xlabel('lateral (Channel)');
    ylabel('axial (Samples)')
end

% get the peak locations
[temporal_peaks_val, temporal_peak_locs] = max(testbedh);
temporal_peak_locs = time_vector(temporal_peak_locs);
if display_graph
    subplot(2,2,2);
    plot(aperture_center_array*1000,  temporal_peak_locs);
    title('Peaks in time domain');
    xlabel('lateral (mm)');
    ylabel('time (s)')
end

% non-linear transform (if recursion)
spatial_peak_locs = (temporal_peak_locs-z_focus/current_guess*2).^2/4;
if display_graph
    subplot(2,2,3);
    plot(aperture_center_array*1000,spatial_peak_locs)
    title('Peaks in Q domain');
    xlabel('lateral (mm)');
    ylabel('Q')
end

% curve-fitting
X = [aperture_center_array.^2, aperture_center_array, ones(size(aperture_center_array))];
W = diag(temporal_peaks_val.^2.*(temporal_peaks_val>0.5*max(temporal_peaks_val)));
q = inv(X'*W*X)*X'*W*spatial_peak_locs';
velocity_estimate = 1/sqrt(q(1));
x_0 =q(2)/q(1)/2;
z_position = sqrt(q(3)/q(1)-x_0^2)+z_focus;
if display_graph
    subplot(2,2,4);
    plot(aperture_center_array, q(1)*aperture_center_array.^2+q(2)*aperture_center_array+q(3),'r',aperture_center_array, spatial_peak_locs)
    title('Fitted Curve');
    xlabel('lateral (mm)');
    ylabel('Q')
    legend('fitted curve', 'observations')
end

end