%% This script estimates the SOS of the system at the scatterer highlighted
% in the last step
depth_vector = zeros(num_para,1);
velocity_vector = zeros(num_para,1);
num_iter_vector  = zeros(num_para,1);
input_pos = zeros(num_para,1);

for i_rec = 1:num_para
    input_pos(i_rec) = image_depth_index(rectangle_vertex(i_rec,2))/1000 +image_depth_index(rectangle_vertex(i_rec,4))/1000;
    input_pos(i_rec) = input_pos(i_rec)/2;
end

depth = 20/1000;
display_graph = 1;
find_filter = 1;
assumed_SOS = 1540;
for i_curve = 1:num_para
    x_start = rectangle_vertex(i_curve,1);
    x_end = rectangle_vertex(i_curve,3);
    y_start = rectangle_vertex(i_curve,2);
    y_end = rectangle_vertex(i_curve,4);
    testbed  = first_stage_buffer(y_start:y_end,x_start:x_end);
    current_guess = 1700;
    lower_bound = current_guess-500;
    upper_bound  = current_guess+500;
    num_iter = 0;
    c_guess = current_guess+50;
    while abs(c_guess - current_guess) > 1 && num_iter < 20
        [c_guess, z_position] = SOS_estimate_speed_of_sound_LS_vs(testbed,assumed_SOS, current_guess,y_start,y_end,fs,aperture_center_array(x_start:x_end),1 ,z_focus);
        new_upper = max(current_guess,c_guess);
        new_lower = min(current_guess,c_guess);
        upper_bound = new_upper;
        lower_bound = new_lower;
        current_guess = round((upper_bound + lower_bound)/2);
        num_iter = num_iter+1;
    end
    
    depth_vector(i_curve) = z_position;
    velocity_vector(i_curve) = c_guess;
    
    num_iter_vector(i_curve) = num_iter;
end
