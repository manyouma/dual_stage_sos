%% This function first generates the LRI image and then highlight the 
%  parabolas in the image

%  need to make sure that the DAQ data is loaded in the DAQ variable,
%  the position of the rectangle vertices and the num_para parameters are
%  defined

%  Required parameters:
%   -- DAQ_data -- 
%   -- pitch --
%   -- f_number_recevie --
%   -- f_number_transmit --

%% Physical properties of the transducer elements
f0 = 7e6;                     %  Transducer center frequency [Hz]
fs = 120e6;                   %  Sampling frequency [Hz]

kerf = 0.035/1000;
width = pitch - kerf;           %  Width of element
element_height = 4.5/1000;    %  Height of element [m]
focus = [0 0 25]/1000;        %  Fixed focal point [m]
fi = 5e6;
num_cycle_excite = 1;
num_cycle_impulse = 1;
N_elements = 128;


z_focus = 20/1000; 

receive_hann = 1;
transmit_hann = 1;
transmit_apo_hann = 1;

impulse_response=sin(2*pi*f0*(0:1/fs:num_cycle_impulse/f0));
impulse_response=impulse_response.*hanning(max(size(impulse_response)))';
excitation=sin(2*pi*fi*(0:1/fs:num_cycle_excite/fi));
excitation=excitation.*hanning(max(size(excitation)))';

m_filter = conv(conv(excitation,impulse_response), impulse_response);
m_filter = flipdim(m_filter,2);
%% Phantom properties
cyst = 1;
simstart =  0.005;
image_depth = size(RF_data, 2);%ceil(max(phantom_positions(:,3))*156*1000)+1500;
image_depth_index = (1:image_depth)/2*c/fs*1000;
%% Parameters of transducer array

N_image = N_elements;                   % Form one line at each imaging position
N_second_stage = N_elements;
% !!!!!!!!!! To change later, if does not match the result !!!!!!!!!!!!
double2odd    = @(x) max(1,floor((x+0.9)/2)*2+1);
N_active = min(65, double2odd(z_focus/f_number_transmit/pitch));                          % Number of elements used to generate a focused transmission
N_receive = N_elements;
N_transmit = N_elements;
%% Scan parameter
% position of each transmission element
aperture_center_array = help_generateCenterArray(N_elements, pitch);
image_center_array =  help_generateCenterArray(N_image, pitch);
transmit_center_index = 1:N_elements;
transmit_center_array = aperture_center_array(transmit_center_index);
receive_mag_matrix =  FOCUS_apodizationMatrix(N_elements, image_depth, 0, fs,c,f_number_receive,receive_hann,pitch);
width_mag_matrix = size(receive_mag_matrix,2);
mag_offset = (N_elements - 1)/2;
first_stage_buffer = zeros(image_depth, N_transmit);

%% Scanning routine
for i_transmit = 1:N_transmit
    current_center_index = transmit_center_index(i_transmit);
    temp_beamform_matrix = squeeze( RF_data(i_transmit, :, :));
    mag_startPos = N_elements + 1 - current_center_index;
    current_mag_matrix = receive_mag_matrix(:, (mag_startPos):(mag_startPos+2*mag_offset));
    first_stage_buffer(:, i_transmit) = FOCUS_srDAS(temp_beamform_matrix,aperture_center_array, aperture_center_array(current_center_index),z_focus, fs, c, current_mag_matrix);
    fprintf('Tranmission:::\t Processing line %d.\t\t %0.05f %% \t finished.\n',i_transmit,i_transmit/N_transmit*100 );
end
final_Image = first_stage_buffer;

%% Perform matched filtering
for i_line = 1:N_transmit
    temp = xcorr(final_Image(:,i_line),m_filter);
    final_Image(:,i_line) = temp(image_depth:end);
end
first_stage_buffer = final_Image;
% %% make the image
close all;
active_center_array = transmit_center_array;
IMG_make_image_sampleChannel;
title('Please select Region of Interest: ')
xlabel('Channels');
ylabel('Samples');
if ~exist('num_para')
    num_para = input('Please enter number of parabolas (max 8):  ');
end
rectangle_vertex = zeros(num_para,4);
color_vec = 'ymcrgbwkymcrgbwk';
i_rec = 1;
for i_rec = 1:num_para
    inputrec = round(ginput(2));
    rectangle_vertex(i_rec,1) = inputrec(1,1);
    rectangle_vertex(i_rec,2) = inputrec(1,2);
    rectangle_vertex(i_rec,3) = inputrec(2,1);
    rectangle_vertex(i_rec,4) = inputrec(2,2);
    rectangle('Position', help_convert_input2_rec(rectangle_vertex(i_rec,:)),'LineWidth',2,'EdgeColor',color_vec(i_rec));
end


