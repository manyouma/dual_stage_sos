%  This function generates a two-layer Field II phantom. It is based on the
%  linearity of the Field II program, and Snell's law is used to calculate
%  the TOF compensations.
%
%

%% properties of phantom material
z_focus = 20/1000;              % Source Depth
c_0 = 1450;                     % represent the true speed-of-sound in the system
c_assumed = 1540;               % represent the assumed speed-of-sound used for transmit
c2 = 1540;                      % Speed of sound in the second layer of the system
%layer_separation = 60/1000     % Depth of the first layer
%% Physical properties of the transducer elements
f0 = 7e6;                       %  Transducer center frequency [Hz]
fs = 120e6;                     %  Sampling frequency [Hz]  
kerf = 0.035/1000;              
pitch = 0.208/1000;             %  Wavelength [m]
width = pitch - kerf;           %  Width of element
element_height = 4.5/1000;      %  Height of element [m]
focus = [0 0 25]/1000;          %  Fixed focal point [m]
fi = 5e6;
num_cycle_excite = 1;
num_cycle_impulse = 1;
N_elements = 128;

%==== F-NUMBER-TRANSMIT
receive_hann = 1;
transmit_hann = 1;
transmit_apo_hann = 1;

impulse_response=sin(2*pi*f0*(0:1/fs:num_cycle_impulse/f0));
impulse_response=impulse_response.*hanning(max(size(impulse_response)))';
excitation=sin(2*pi*fi*(0:1/fs:num_cycle_excite/fi));
excitation=excitation.*hanning(max(size(excitation)))';

m_filter = conv(conv(excitation,impulse_response), impulse_response);
m_filter = flipdim(m_filter,2);

%% Phantom properties


simstart =  0.005;
phantom_positions_G = [0 0 simstart;
    0 0 simstart+0.01;
    0 0 simstart+0.02;
    0 0 simstart+0.03;
    0 0 simstart+0.04;
    0 0 simstart+0.05;
    0 0 simstart+0.06;
    0 0 simstart+0.07;
    0 0 simstart+0.08;
    0 0 simstart+0.09;
    0 0 simstart+0.10;
    0 0 simstart+0.11];
phantom_amplitudes_G = 10*ones(size(phantom_positions_G,1),1);


%% Parameters of transducer array
N_image = N_elements;                                                                     % Form one line at each imaging position
N_second_stage = N_elements;
N_receive = N_elements;
N_transmit = N_elements;

%% Scan parameter
% position of each transmission element
aperture_center_array = help_generateCenterArray(N_elements, pitch);
image_center_array =  help_generateCenterArray(N_image, pitch);

transmit_center_index = 1:N_elements;
transmit_center_array = aperture_center_array(transmit_center_index);
image_depth =ceil(max(phantom_positions_G(:,3))*2/c_0*fs)+1500;
image_depth_array = (1:image_depth)/2*c_0/fs;
RF_data_final = zeros(N_elements, image_depth, N_elements);
%% Get the RF signal from the fat layer
% -----------
% Repeat for each scatterer
% -------------
parfor i_transmit = 1:128
    field_init;
    set_sampling(fs);
    set_field('c', c_0);
    set_field('fs', fs)
    for i_scatter = 1:size(phantom_positions_G,1);
        
        
        scatter_x = phantom_positions_G(i_scatter, 1);
        scatter_y = phantom_positions_G(i_scatter, 3);
        scatter_position = [scatter_x,scatter_y];
        tof_difference_reference = help_two_layer_delay(scatter_position, aperture_center_array, layer_separation, c_0, c2, fs);
        phantom_positions = [scatter_x, 0, scatter_y];
        phantom_amplitudes = 10*ones(size(phantom_positions,1),1);
        
        
        
        
        N_active = 65;
        
        current_center_index = transmit_center_index(i_transmit);
        % do the total number of transmissions
        emit_aperture = xdc_linear_array(N_elements, width, element_height, kerf, 1, 1,focus);
        receive_aperture = xdc_linear_array (N_elements, width, element_height, kerf, 1, 1,focus);
        xdc_impulse(emit_aperture, impulse_response);
        xdc_impulse(receive_aperture, impulse_response);
        xdc_excitation(emit_aperture, excitation);
        
        % determine the transmit apodization
        trans_apo_vector = zeros(1,N_elements);
        receive_apo_vector = zeros(1,N_elements);
        
        % determine the active transmit aperture
        if current_center_index < (N_active+1)/2
            apo_start = 1;
            apo_end = N_active;
        elseif current_center_index > N_elements -(N_active+1)/2
            apo_start = N_elements-N_active+1;
            apo_end = N_elements;
        else
            apo_start = current_center_index-(N_active-1)/2;
            apo_end = current_center_index+(N_active-1)/2;
        end
        
        % -----------
        % Repeat for each transmit element
        % -------------
        for i_active = 1:N_active
            special_ones =  zeros(1,N_active);
            special_ones(i_active)  = 1;
            % apply a hamming window to the transmit aperture
            if transmit_apo_hann
                trans_apo_vector(apo_start: apo_end) = special_ones.*hamming(N_active)';
            else
                trans_apo_vector(apo_start: apo_end) = special_ones;
            end
            
            
            receive_apo_vector(apo_start: apo_end) =   ones(1,N_active);
            xdc_apodization (emit_aperture, 0, trans_apo_vector);
            xdc_apodization (receive_aperture, 0, receive_apo_vector);
            
            % set the focus of the two apertures
            xdc_center_focus(emit_aperture,[transmit_center_array(i_transmit) 0 0]);
            xdc_focus_times(emit_aperture, 0,  help_transmitDelayVector([transmit_center_array(i_transmit),0,z_focus], c_assumed, aperture_center_array ));
            
            xdc_center_focus(receive_aperture,[transmit_center_array(i_transmit)  0 0]);
            xdc_focus(receive_aperture, 0, [transmit_center_array(i_transmit) , 0, 10000] );
            [v, t1]=calc_scat_multi(emit_aperture, receive_aperture, phantom_positions, phantom_amplitudes);
            temp_unit_matrix =  help_convert2FullLength(v,t1,fs,c_0,image_depth);
            % check which layer the scatterer belongs to, shift signal if it
            % belongs to the second layer
            if scatter_y > layer_separation
                for i_receive = 1:128
                    num_shift = tof_difference_reference(i_transmit) + tof_difference_reference(i_receive);
                    if num_shift > 0
                        % shift forward
                        temp_unit_matrix(num_shift+1:end,i_receive) = temp_unit_matrix(1:end-num_shift,i_receive);
                    else
                        % shift backward
                        num_shift = abs(num_shift);
                        temp_unit_matrix(1:end-num_shift,i_receive) = temp_unit_matrix(num_shift+1:end,i_receive);
                    end
                end
            end
            RF_data_final(i_transmit, :,:) = squeeze(RF_data_final(i_transmit, :,:))+ temp_unit_matrix;
        end
        
        
    end
    xdc_free(emit_aperture);
    xdc_free(receive_aperture);
    
end

