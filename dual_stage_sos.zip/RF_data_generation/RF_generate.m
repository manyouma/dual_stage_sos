%%
% 
%  This script creates the per-channel RF data for a 10 point PFS phantom.
%  The output are located in the variable RF_data.
% 


%% Physical properties of the transducer elements
f0 = 7e6;                       %  Transducer center frequency [Hz]
fs = 120e6;                     %  Sampling frequency [Hz]
kerf = 0.035/1000;
pitch = 0.208/1000;             %  Wavelength [m]
width = pitch - kerf;           %  Width of element
element_height = 4.5/1000;      %  Height of element [m]
focus = [0 0 25]/1000;          %  Fixed focal point [m]
fi = 5e6;
num_cycle_excite = 1;
num_cycle_impulse = 1;
N_elements = 128;
% z_focus = 20/1000;            % Virtual source Depth 


%==== Beamforming parameters
receive_hann = 1;
transmit_hann = 1;
transmit_apo_hann = 1;

impulse_response=sin(2*pi*f0*(0:1/fs:num_cycle_impulse/f0));
impulse_response=impulse_response.*hanning(max(size(impulse_response)))';
excitation=sin(2*pi*fi*(0:1/fs:num_cycle_excite/fi));
excitation=excitation.*hanning(max(size(excitation)))';

m_filter = conv(conv(excitation,impulse_response), impulse_response);
m_filter = flipdim(m_filter,2);

%% Phantom properties
cyst = 0;
simstart =  0.005;

phantom_positions = [0 0 simstart;
    0 0 simstart+0.01;
    0 0 simstart+0.02;
    0 0 simstart+0.03;
    0 0 simstart+0.04;
    0 0 simstart+0.05;
    0 0 simstart+0.06;
    0 0 simstart+0.07;
    0 0 simstart+0.08;
    0 0 simstart+0.09;
    ];

phantom_amplitudes = 10*ones(size(phantom_positions,1),1);
%% Parameters of transducer array
N_image = N_elements;                                                                     % Form one line at each imaging position
N_second_stage = N_elements;
double2odd    = @(x) max(1,floor((x+0.9)/2)*2+1);
% Number of elements used to generate a focused transmission
N_receive = N_elements;
N_transmit = N_elements;

%% Scan parameter
% position of each transmission element
aperture_center_array = help_generateCenterArray(N_elements, pitch);
image_center_array =  help_generateCenterArray(N_image, pitch);

transmit_center_index = 1:N_elements;
transmit_center_array = aperture_center_array(transmit_center_index);
image_depth =ceil(max(phantom_positions(:,3))*2/c*fs)+1500;

RF_data = zeros(N_elements, image_depth, N_elements);
%% Get the RF signal from the fat layer
field_init;
set_sampling(fs);
set_field('c', c);
set_field('fs', fs)

for i_transmit = 1:N_transmit
    
    N_active = 65;
    
    current_center_index = transmit_center_index(i_transmit);
    % do the total number of transmissions
    % initialize the two apertures
    emit_aperture = xdc_linear_array(N_elements, width, element_height, kerf, 1, 1,focus);
    receive_aperture = xdc_linear_array (N_elements, width, element_height, kerf, 1, 1,focus);
    xdc_impulse(emit_aperture, impulse_response);
    xdc_impulse(receive_aperture, impulse_response);
    xdc_excitation(emit_aperture, excitation);
    
    % determine the transmit apodization
    trans_apo_vector = zeros(1,N_elements);
    receive_apo_vector = zeros(1,N_elements);
    
    % determine the active transmit aperture
    if current_center_index < (N_active+1)/2
        apo_start = 1;
        apo_end = N_active;
    elseif current_center_index > N_elements -(N_active+1)/2
        apo_start = N_elements-N_active+1;
        apo_end = N_elements;
    else
        apo_start = current_center_index-(N_active-1)/2;
        apo_end = current_center_index+(N_active-1)/2;
    end
    
    % apply a hamming window to the transmit aperture
    if transmit_apo_hann
        trans_apo_vector(apo_start: apo_end) =  ones(1,N_active).*hamming(N_active)';
    else
        trans_apo_vector(apo_start: apo_end) =  ones(1,N_active);
    end
    
    receive_apo_vector(apo_start: apo_end) =   ones(1,N_active);
    xdc_apodization (emit_aperture, 0, trans_apo_vector);
    xdc_apodization (receive_aperture, 0, receive_apo_vector);
    
    % set the focus of the two apertures
    xdc_center_focus(emit_aperture,[transmit_center_array(i_transmit) 0 0]);
%     xdc_focus(emit_aperture, 0, [transmit_center_array(i_transmit) , 0, z_focus] );
    xdc_focus_times(emit_aperture, 0,  help_transmitDelayVector([transmit_center_array(i_transmit),0,z_focus], c_assumed, aperture_center_array ));

    
    xdc_center_focus(receive_aperture,[transmit_center_array(i_transmit)  0 0]);
    xdc_focus(receive_aperture, 0, [transmit_center_array(i_transmit) , 0, 10000] );
    [v, t1]=calc_scat_multi(emit_aperture, receive_aperture, phantom_positions, phantom_amplitudes);
    RF_data(i_transmit, :,:) = help_convert2FullLength(v,t1,fs,c,image_depth);
    fprintf('Tranmission:::\t Processing line %d.\t\t %0.05f %% \t finished.\n',i_transmit,i_transmit/N_transmit*100 );
    
    
end
xdc_free(emit_aperture);
xdc_free(receive_aperture);






